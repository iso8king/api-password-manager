import { prismaClient } from "../application/database.js";
import bcrypt from 'bcrypt'
import jwt from 'jsonwebtoken'
import { validate } from "../validation/validate.js";
import { responseError } from "../error/response-error.js";
import { stringify } from "uuid";
import { savePasswordValidation, updateSavedPasswordValidation } from "../validation/password-validation.js";

const createPassword = async(user_id,request)=>{
    request = validate(savePasswordValidation, request)

    request.password = await bcrypt.hash(request.password, 10);

    const data = {
        ...request,
        user_id
    }

    return prismaClient.password_manager.create({
        data : data
    })
}

const updateSavedPassword = async(request)=>{
    request = validate(updateSavedPasswordValidation, request)
    const data = {}

    const field = ["id", 'nama' , "deskripsi"]
    for (const f of field) {
        if (request[f] !== undefined && request[f] !== "undefined") {
            data[f] = request[f];
        }
    }

    if(request.password){
        const hashPassword = await bcrypt.hash(request.password, 10)
        data.password = hashPassword
    }

    console.log(data)

    return prismaClient.password_manager.update({
        where : {
            id : request.id
        }, data: data
    })

}

const readAllPassword = async(id_password)=>{
    const password_on_accout = await prismaClient.password_manager.findMany({
        where : {
            id : id_password
        }
    });

    for (const f of password) {
        password_on_accout.password[f] = await bcrypt()

    }
}

export default{
    createPassword,updateSavedPassword
}